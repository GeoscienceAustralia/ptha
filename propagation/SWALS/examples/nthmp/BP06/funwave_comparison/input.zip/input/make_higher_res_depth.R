# Mesh refinement of "depth.txt" in the Funwave conical island example
input_file = 'depth.txt'
o_dx = 0.05
o_nx = 702
o_ny = 602

# Original x/y/depth
orig_x = matrix(o_dx/2 + seq(0, o_nx-1)*o_dx, ncol=o_ny, nrow=o_nx)
orig_y = matrix(o_dx/2 + seq(0, o_ny-1)*o_dx, ncol=o_ny, nrow=o_nx, byrow=TRUE)
orig_depth = matrix(scan(input_file), nrow=o_nx)

# New x/y values where we interpolate the grid
refine = 2 # Integer
n_dx = o_dx/refine
new_x = n_dx + seq(0, o_nx*refine - 1)*n_dx
new_y = n_dx + seq(0, o_ny*refine - 1)*n_dx
newXY = expand.grid(new_x, new_y)

# Interpolation
library(rptha)
oldXY = cbind(c(orig_x), c(orig_y))
y = triangular_interpolation(oldXY, c(orig_depth), newXY)
dim(y) = c(length(new_x), length(new_y))

# This is still not in the funwave format, which needs to pass through 'format.f' first
write.table(y, file=paste0(input_file, '_refined_', refine, '.out'), row.names=FALSE, col.names=FALSE)

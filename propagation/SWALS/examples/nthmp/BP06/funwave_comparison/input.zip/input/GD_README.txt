The original problem used 'depth.txt' as the input data.

To do mesh refinement studies I wrote 'make_higher_res_depth.R', which interpolates 'depth.txt' at double resolution.

Funwave has a very particular input data format, which for the original example requires passing the matlab output through 'format.f'. I made a new version 'format_refine2.f' for the higher res data
